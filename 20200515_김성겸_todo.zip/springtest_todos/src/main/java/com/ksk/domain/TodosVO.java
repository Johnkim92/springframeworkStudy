package com.ksk.domain;

import java.util.Date;

import lombok.Data;

@Data
public class TodosVO {
	private Long bno;
	private String writer;
	private String doDate;
	private Date regDate;
	private String todo;
	private String done_stat;
	private String sign;
	private Date updateDate;
}
