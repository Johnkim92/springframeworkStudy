package com.ksk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ksk.domain.TodosVO;
import com.ksk.mapper.TodosMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;
@Service
@Log4j
@AllArgsConstructor
public class TodosServiceImpl implements TodosService {
	
	@Setter(onMethod_=@Autowired)
	private TodosMapper mapper;

	@Override
	public List<TodosVO> getList() {
		log.info("getList....");
		return mapper.getList();
	}

	@Override
	public TodosVO get(Long bno) {
		log.info("get...."+bno);
		return mapper.read(bno);
	}

	@Override
	public boolean modify(TodosVO todos) {
		log.info("Modify"+todos);
		return mapper.update(todos)==1;
	}

	@Override
	public boolean modifyStat(TodosVO todos) {
		log.info("modifyStat: "+todos);
		return mapper.updateDoneStat(todos)==1;
	}

	@Override
	public boolean remove(Long bno) {
		log.info("remove : "+bno);
		return mapper.delete(bno)==1;
	}

	@Override
	public void register(TodosVO todos) {
		mapper.insertSelectKey(todos);
		log.info("register....."+todos);

	}

}
