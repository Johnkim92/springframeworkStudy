package com.ksk.service;

import java.util.List;

import com.ksk.domain.TodosVO;

public interface TodosService {
	
	public List<TodosVO> getList();
	
	public TodosVO get(Long bno);
	
	public boolean modify(TodosVO todos);
	
	public boolean modifyStat(TodosVO todos);
	
	public boolean remove(Long bno);
	
	public void register(TodosVO todos);
}
