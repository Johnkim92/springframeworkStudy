package com.ksk.mapper;

import java.util.List;

import com.ksk.domain.TodosVO;

public interface TodosMapper {
	
	public List<TodosVO> getList();
	
	public void insertSelectKey(TodosVO todos);
	
	public TodosVO read(Long bno);
	
	public int delete(Long bno);
	
	public int update(TodosVO todos);
	
	public int updateDoneStat(TodosVO todos);

}
