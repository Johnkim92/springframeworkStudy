package com.ksk.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ksk.domain.TodosVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@Log4j
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class TodosServiceTests {
	
	@Setter(onMethod_=@Autowired)
	private TodosService service;
	
	//@Test
	public void testExist() {
		log.info(service);
		assertNotNull(service);
	}
	
	//@Test
	public void testRegister() {
		TodosVO todos = new TodosVO();
		todos.setTodo("새로작성하는 일정 테스트2");
		todos.setDoDate("20200521");
		todos.setWriter("newbie test2");
		service.register(todos);
		log.info("생성된 개시물의 번호 : "+todos.getBno());
	}
	//@Test
	public void testGet() {
		log.info(service.get(1L));
	}
	
	//@Test
	public void testRemove() {
		log.info("REMOVE RESULT : "+service.remove(6L));
	}
	
	//@Test
	public void testUpdate() {
		TodosVO todos = service.get(1L);
		
		if(todos==null) {
			return;
		}
		
		todos.setTodo("할일 수정을 테스트합니다");
		log.info("MODIFY RESULT : "+service.modify(todos));
	}
	
	@Test
	public void testUpdateDoneStat() {
		TodosVO todos = service.get(2L);
		
		if(todos==null) {
			return;
		}
		todos.setDone_stat("2");
		log.info("ModifyState Result : "+service.modifyStat(todos));
	}


}
