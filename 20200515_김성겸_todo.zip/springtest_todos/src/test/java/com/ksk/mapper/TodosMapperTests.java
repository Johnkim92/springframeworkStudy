package com.ksk.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ksk.domain.TodosVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class TodosMapperTests {
	
	@Setter(onMethod_=@Autowired)
	TodosMapper mapper;
	
	//@Test
	public void testGetList() {
		mapper.getList().forEach(todos -> log.info(todos));
	}
	
	//@Test
	public void testInsertSelectKey() {
		TodosVO todos = new TodosVO();
		todos.setDoDate("'20200516'");
		todos.setTodo("codingtest 연습");
		todos.setWriter("김성겸");
		mapper.insertSelectKey(todos);
		log.info(todos);
	}
	
	//@Test
	public void testRead() {
		TodosVO todos = mapper.read(3L);
		log.info(todos);
	}
	
	//@Test
	public void testUpdate() {
		TodosVO todos = new TodosVO();
		todos.setTodo("테스트");
		todos.setWriter("테스트2");
		todos.setSign("서명12");
		todos.setDoDate("'20200517'");
		todos.setBno(5L);
		log.info("UPDATE COUNT : "+mapper.update(todos));
	}
	
	//@Test
	public void testUpdateDoneStat() {
		TodosVO todos = new TodosVO();
		todos.setBno(5L);
		todos.setDone_stat("2");
		log.info("UPDATEDoneStat : "+mapper.updateDoneStat(todos));
		
	}
	
	//@Test
	public void testDelete() {
		log.info("DELETE : "+mapper.delete(5L));
	}

}
