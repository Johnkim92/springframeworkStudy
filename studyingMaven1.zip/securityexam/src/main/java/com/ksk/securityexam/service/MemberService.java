package com.ksk.securityexam.service;

import com.ksk.securityexam.service.security.UserDbService;

public interface MemberService extends UserDbService{
	
}
