package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import board.dto.*;

public class BoardDAO {
	DataSource ds;
	
	/** DB 연결을 위한 메서드**/
	public BoardDAO(){
		try {
			Context ctx =new InitialContext();
			ds=(DataSource) ctx.lookup("java:comp/env/jdbc/orcl");
			System.out.println("ds : "+ds);
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}	// public BoardDAO() END
	
	/** 개인 보유 계좌 목록 메서드**/
	public ArrayList<BoardDTO> list(){
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
		try {
			String sql="SELECT * FROM MYACCOUNT ORDER BY OPEN_DATE DESC";
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				BoardDTO data = new BoardDTO();
				data.setAccount_num(rs.getInt("account_num"));
				data.setAccount_type(rs.getInt("account_type"));
				data.setBalance(rs.getInt("balance"));
				data.setName(rs.getString("name"));
				data.setOpen_date(rs.getString("open_date"));
				
				list.add(data);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}	// public ArrayList<BoardDTO> list() END
	
	/**	 계좌번호 자동얻기 매서드	**/
	public int getNewAccount_num(){
		int newAccount_num=1;
		try {
			String sql="select max(account_num) from myaccount";
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs =pstmt.executeQuery();
			if(rs.next()){
				newAccount_num=(rs.getInt(1)+1);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return newAccount_num;
	}	//  public int getNewAccount_num() END
	
	/** 계좌 생성 매서드 **/
	public void create(String name, int account_type, int balance){
		int account_num=this.getNewAccount_num();
		String sql="INSERT INTO MYACCOUNT (ACCOUNT_NUM, ACCOUNT_TYPE, NAME, BALANCE) VALUES (?, ?, ?, ?)";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			pstmt.setInt(2, account_type);
			pstmt.setString(3, name);
			pstmt.setInt(4, balance);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	// public void create(String name, int account_type, int balance) END
	
	/** 거래 조회 매서드 **/
	public ArrayList  inquiry(int account_num){
		ArrayList inquiry = new ArrayList();
		try {
			String sql="select i.*, o.*, r.res from res_tab r left outer join input_tab i on r.res = i.i_res_date and r.account_num = i.account_num left outer join output_tab o on r.res=o.o_res_date and r.account_num = o.account_num where r.account_num = ?";
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			ResultSet rs =pstmt.executeQuery();
			while(rs.next()){
				InquiryDTO data = new InquiryDTO();
				data.setDeposit(rs.getInt("deposit"));
				data.setInput_type(rs.getInt("input_type"));
				data.setI_res_date(rs.getString("i_res_date"));
				data.setSender(rs.getString("sender"));
				data.setMessage(rs.getString("message"));
				data.setOutput_type(rs.getInt("output_type"));
				data.setReceive_account(rs.getInt("receive_account"));
				data.setReceiver(rs.getString("receiver"));
				data.setWithdraw(rs.getInt("withdraw"));
				data.setO_res_date(rs.getString("o_res_date"));
				data.setMemo(rs.getString("memo"));
				data.setAccount_num(rs.getInt("account_num"));
				data.setRes(rs.getString("res"));
				inquiry.add(data);		
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return inquiry;
	}	// public ArrayList inquiry(int account_num) END
	
	public void deposit(int account_num, int input_type, int deposit, String sender, String message){
		String sql="insert into input_tab (account_num, input_type, deposit, sender, message) values (?, ?, ?, ?, ?)";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			pstmt.setInt(2, input_type);
			pstmt.setInt(3, deposit);
			pstmt.setString(4, sender);
			pstmt.setString(5, message);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
			System.out.println("입금 쿼리 실행!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	// public void deposit(int account_num, int deposit, String sender, String message) END
	public String selectIdate(int account_num){
		String sql="select max(i_res_date) from input_tab where account_num =?";
		String i_res_date="";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				i_res_date=rs.getString(1);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("i_res_date : "+ i_res_date);
		return i_res_date;
	}
	public void updateMyaccountI(int account_num, int deposit){	// 수정 할것
		String sql="update myaccount set m_res_date = to_date(?, 'yyyy-mm-dd hh24:mi:ss' ), balance = ? where account_num =?";
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, this.selectIdate(account_num));
			pstmt.setInt(2, this.checkbalance(account_num)+deposit);
			pstmt.setInt(3, account_num);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	// public void updateMyaccount(int account_num);
	
	public String maxIResDate(int account_num){
		String sql="select max(i_res_date) from input_tab where account_num = ?";
		String i_res_date="";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			i_res_date=rs.getString(1);
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("max(i_res_date) : "+i_res_date);
		return i_res_date;
	}
	
	public void insertResI(int account_num){
		String sql="insert into res_tab (account_num, i_res_date) values (?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'))";
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			pstmt.setString(2, this.maxIResDate(account_num));
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
			System.out.println("res_tab 값 추가");
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}	// public void insertRes(int account_num) END
	
	public void withdraw(int account_num, int output_type, int withdraw, int receive_account, String receiver, String memo){
		String sql="insert into output_tab (account_num, output_type, withdraw, receive_account, receiver, memo) values (?, ?, ?, ?, ?, ?)";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			pstmt.setInt(2, output_type);
			pstmt.setInt(3, withdraw);
			pstmt.setInt(4, receive_account);
			pstmt.setString(5, receiver);
			pstmt.setString(6, memo);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
			System.out.println("출금 메서드 실행");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String selectOdate(int account_num){
		String sql="select max(o_res_date) from output_tab where account_num =?";
		String o_res_date="";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				o_res_date=rs.getString(1);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return o_res_date;
	}
	
	public int checkbalance(int account_num){
		String sql="select balance from myaccount where account_num = ?";
		int balance = 0;
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			balance = rs.getInt(1);
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;
	}
	
	public String updateMyaccountO(int account_num, int withdraw){
		String sql="update myaccount set m_res_date = to_date(?, 'yyyy-mm-dd hh24:mi:ss'), balance = ? where account_num = ?";
		String success="";
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			int currentBalance = this.checkbalance(account_num);
			if (currentBalance> withdraw){
				pstmt.setString(1, this.selectOdate(account_num));
				pstmt.setInt(2, currentBalance-withdraw);
				pstmt.setInt(3, account_num);
				int n=pstmt.executeUpdate();
				if(n > 0){
					success="출금 성공";
				}else{
					success="출금 실패";
				}
			}else{
				success="출금 실패";
			}
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("success : "+success);
		return success;
	}	// public void updateMyaccount(int account_num);
	
	public void insertResO(int account_num){
		String sql="insert into res_tab (account_num, o_res_date) values (?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'))";
		try {
			Connection con = ds.getConnection();
			PreparedStatement pstmt =con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			pstmt.setString(2, this.maxOResDate(account_num));
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	// public void insertRes(int account_num) END
	
	public String maxOResDate(int account_num){
		String sql="select max(o_res_date) from output_tab where account_num = ?";
		String o_res_date="";
		try {
			Connection con =ds.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, account_num);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			o_res_date=rs.getString(1);
			rs.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return o_res_date;
	}
}
