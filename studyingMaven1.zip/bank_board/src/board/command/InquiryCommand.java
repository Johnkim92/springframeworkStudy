package board.command;

public class InquiryCommand {

	private int account_num;
	
	public int getAccount_num() {
		return account_num;
	}

	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}

	public InquiryCommand() {
	}

}
