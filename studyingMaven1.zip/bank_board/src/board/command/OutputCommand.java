package board.command;

public class OutputCommand {
	private int account_num, output_type, withdraw,receive_account;
	private String receiver, memo;
	
	public int getAccount_num() {
		return account_num;
	}
	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}
	public int getOutput_type() {
		return output_type;
	}
	public void setOutput_type(int output_type) {
		this.output_type = output_type;
	}
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	public int getReceive_account() {
		return receive_account;
	}
	public void setReceive_account(int receive_account) {
		this.receive_account = receive_account;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public OutputCommand(){
		
	}
}
