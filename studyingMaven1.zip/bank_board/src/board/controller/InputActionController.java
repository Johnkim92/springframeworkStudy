package board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractCommandController;

import board.command.InputCommand;
import board.dao.BoardDAO;

public class InputActionController extends AbstractCommandController {
	
	private BoardDAO dao;

	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}

	@Override
	protected ModelAndView handle(HttpServletRequest request, HttpServletResponse response, Object command, BindException error)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		InputCommand data = (InputCommand)command;
		int account_num =data.getAccount_num();
		int input_type=data.getInput_type();
		int deposit = data.getDeposit();
		String message = data.getMessage();
		String sender = data.getSender();
		
		dao.deposit(account_num, input_type, deposit, sender, message);
		dao.insertResI(account_num);
		dao.updateMyaccountI(account_num, deposit);
		
		response.sendRedirect("list.do");
		return null;
	}

}
