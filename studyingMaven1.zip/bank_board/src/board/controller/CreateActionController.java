package board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractCommandController;

import board.command.BoardCommand;
import board.dao.BoardDAO;

public class CreateActionController extends AbstractCommandController {
	
	private BoardDAO dao;

	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}

	@Override
	protected ModelAndView handle(HttpServletRequest request, HttpServletResponse response, Object command, BindException error)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		BoardCommand data =(BoardCommand)command;
		String name=data.getName();
		int account_type=data.getAccount_type();
		int balance =data.getBalance();
		dao.create(name, account_type, balance);
		ModelAndView mav =new ModelAndView();
		mav.setViewName("index");
		return mav;
	}

}
