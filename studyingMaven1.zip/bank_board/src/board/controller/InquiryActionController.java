package board.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractCommandController;

import board.command.InquiryCommand;
import board.dao.BoardDAO;

public class InquiryActionController extends AbstractCommandController {
	
	private BoardDAO dao;

	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}

	@Override
	protected ModelAndView handle(HttpServletRequest request, HttpServletResponse response, Object command, BindException error)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		InquiryCommand data = (InquiryCommand)command;
		int account_num = data.getAccount_num();
		System.out.println("inquiry account_num : "+account_num);
	    ArrayList inquiry = new ArrayList();
	    inquiry=dao.inquiry(account_num);
	    ModelAndView mav = new ModelAndView();
	    mav.addObject("inquiry", inquiry);
	    mav.setViewName("inquiry");
		return mav;
	}

}
