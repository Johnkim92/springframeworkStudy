package board.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractCommandController;

import board.command.OutputCommand;
import board.dao.BoardDAO;

public class OutputActionController extends AbstractCommandController {
	
	private BoardDAO dao;

	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}

	@Override
	protected ModelAndView handle(HttpServletRequest request, HttpServletResponse response, Object command, BindException error)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		OutputCommand data =(OutputCommand)command;
		int account_num =data.getAccount_num();
		int output_type =data.getOutput_type();
		int receive_account =data.getReceive_account();
		int withdraw =data.getWithdraw();
		String memo = data.getMemo();
		String receiver = data.getReceiver();
		
		String success = dao.updateMyaccountO(account_num, withdraw);
		ModelAndView mav = new ModelAndView();
		if(success.equals("출금 성공")){
			dao.withdraw(account_num, output_type, withdraw, receive_account, receiver, memo);
			dao.insertResO(account_num);
			dao.deposit(receive_account, output_type, withdraw, receiver, memo);
			dao.insertResI(receive_account);
			dao.updateMyaccountI(receive_account, withdraw);
			RequestDispatcher rd = request.getRequestDispatcher("list.do");
			rd.forward(request, response);
		} else{
			mav.setViewName("output");
			mav.addObject("success", success);
			System.out.println(success);
		}
		
		return mav;
	}

}
