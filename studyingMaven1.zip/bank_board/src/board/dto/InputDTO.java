package board.dto;

public class InputDTO {
	private int account_num, input_type, deposit =0;
	private String sender, message, i_res_date;
	public int getAccount_num() {
		return account_num;
	}
	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}
	public int getInput_type() {
		return input_type;
	}
	public void setInput_type(int input_type) {
		this.input_type = input_type;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public String getI_res_date() {
		return i_res_date;
	}
	public void setI_res_date(String i_res_date) {
		this.i_res_date = i_res_date;
	}
	public InputDTO(){
		
	}
}
