package board.dto;

public class BoardDTO {
	private int account_num;
	private int account_type;
	private int balance;
	private String name;
	private String open_date, m_res_date;
	
	public int getAccount_num() {
		return account_num;
	}



	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}



	public int getAccount_type() {
		return account_type;
	}



	public void setAccount_type(int account_type) {
		this.account_type = account_type;
	}



	public int getBalance() {
		return balance;
	}



	public void setBalance(int balance) {
		this.balance = balance;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getOpen_date() {
		return open_date;
	}



	public void setOpen_date(String open_date) {
		this.open_date = open_date;
	}






	public String getM_res_date() {
		return m_res_date;
	}



	public void setM_res_date(String m_res_date) {
		this.m_res_date = m_res_date;
	}



	public  BoardDTO(){
	}
}
