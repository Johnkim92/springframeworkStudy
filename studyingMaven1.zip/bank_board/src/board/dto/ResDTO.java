package board.dto;

public class ResDTO {
	int account_num;
	String i_res_date, o_res_date, res;

	public int getAccount_num() {
		return account_num;
	}

	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}

	public String getI_res_date() {
		return i_res_date;
	}

	public void setI_res_date(String i_res_date) {
		this.i_res_date = i_res_date;
	}

	public String getO_res_date() {
		return o_res_date;
	}

	public void setO_res_date(String o_res_date) {
		this.o_res_date = o_res_date;
	}

	public String getRes() {
		return res;
	}

	public void setRes(String res) {
		this.res = res;
	}

	public ResDTO() {
		// TODO Auto-generated constructor stub
	}

}
