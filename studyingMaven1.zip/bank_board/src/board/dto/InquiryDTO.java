package board.dto;

public class InquiryDTO {
	
	private int deposit, input_type, output_type, receive_account, withdraw, account_num;
	private String i_res_date, sender, message, receiver, o_res_date, memo, res;

	public int getDeposit() {
		return deposit;
	}

	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}

	public int getInput_type() {
		return input_type;
	}

	public void setInput_type(int input_type) {
		this.input_type = input_type;
	}

	public int getOutput_type() {
		return output_type;
	}

	public void setOutput_type(int output_type) {
		this.output_type = output_type;
	}

	public int getReceive_account() {
		return receive_account;
	}

	public void setReceive_account(int receive_account) {
		this.receive_account = receive_account;
	}

	public int getWithdraw() {
		return withdraw;
	}

	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}

	public int getAccount_num() {
		return account_num;
	}

	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}

	public String getI_res_date() {
		return i_res_date;
	}

	public void setI_res_date(String i_res_date) {
		this.i_res_date = i_res_date;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getO_res_date() {
		return o_res_date;
	}

	public void setO_res_date(String o_res_date) {
		this.o_res_date = o_res_date;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getRes() {
		return res;
	}

	public void setRes(String res) {
		this.res = res;
	}

	public InquiryDTO() {
	}

}
