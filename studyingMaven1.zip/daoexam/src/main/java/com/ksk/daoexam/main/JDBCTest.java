package com.ksk.daoexam.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ksk.daoexam.config.ApplicationConfig;
import com.ksk.daoexam.dao.RoleDao;
import com.ksk.daoexam.dto.Role;

public class JDBCTest {

	public static void main(String[] args) {
		ApplicationContext ac = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		RoleDao roleDao = ac.getBean(RoleDao.class);
		
		Role role = new Role();
		role.setRoleId(202);
		role.setDescription("PROGRAMMERs");
		
		int count = roleDao.insert(role);
		System.out.println(count+"건 입력완료");
		
		int count1 = roleDao.update(role);
		System.out.println(count1+"건 수정완료");
		
		Role resultRole = roleDao.selectById(201);
		System.out.println(resultRole);
		
		int deleteCount = roleDao.deleteById(500);
		System.out.println(deleteCount+"건 삭제완료");
		
		Role resultRole2 = roleDao.selectById(500);
		System.out.println(resultRole2);
	}

}
